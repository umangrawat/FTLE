#include<iostream>
#include <vector>
#include <list>
#include <algorithm>

using namespace std;

//Directed Graph
class DirectedGraph
{
    int N;    // Nodes
    std::vector<int> *adj;   //adjacency matrix
    bool CheckforCycle (int n, bool checked[]);
public:
    DirectedGraph(int N);
    void edge(int v, int w);   //add an edge
    std::vector<int> elements;
    bool Cycle();
    friend class ElemCycle;    //Friend class
};


class ElemCycle{
public:
    bool haveSameElemCycles(const DirectedGraph& a, const DirectedGraph& b) const;
};

//Specify nodes and adjacency matrix size
DirectedGraph::DirectedGraph(int N)
{
    this->N = N;
    adj= new std::vector<int>[N];
}

//add edge
void DirectedGraph::edge(int v, int w)
{
    adj[v].push_back(w); // Add only once for directed graph
}

//Check if there's a cycle
bool DirectedGraph::CheckforCycle(int n, bool checked[])
{
    if(!checked[n])
    {
        checked[n] = true;
        std::vector<int>::iterator i;
        for ( i = adj[n].begin(); i < adj[n].end(); i++)
        {
            if (!checked[*i])
            {
                //std::cout<< *i<<" ";
                elements.push_back(*i);
                if (CheckforCycle(*i, checked)) {
                    return true;
                }
            }
            else
            {
                elements.push_back(*i);
                //std::cout<< *i<<" ";
                return true;
            }
        }
        //std::cout<<std::endl;
    }
    checked[n] = false;
    return false;
}

bool DirectedGraph::Cycle()
{
    auto *checked = new bool[N];
    //std::vector<int> cycleElem;

    for (int i = 0; i < N; ++i) {
        checked[i] = false;
    }

    for (int j = 0; j < N; ++j) {

        if (CheckforCycle(j,checked))
        {
            int vecSize = elements.size();
            for (int k = 0; k < vecSize; k++ )
            {
                //std::cout<<cycleElem.at(k) << std::endl;
            }

            return true;
        }
        else
        {
            return false;
        }
    }

}

//check for Elementary cycle
bool ElemCycle::haveSameElemCycles( const DirectedGraph& a, const DirectedGraph& b) const
{
    if (a.Cycle() && b.Cycle())
    {
        std::cout <<"There exist cycles in A and B"<<std::endl;
        //bool flag = false;

        std::vector<int> cycleElementsA;
        std::vector<int> cycleElementsB;

        std::cout<<"Checking for elementary cycles"<<std::endl;

        //Cycle in a

        for (int l = 0; l < a.elements.size() -1 ; l++)
        {
            int countA = std::count(a.elements.begin(), a.elements.end(), a.elements.at(l));
            //std::cout<<"Num " << a.cycleElem.at(l) << "appears " << mycount <<std::endl;

            if (countA > 1)
            {
                std::cout<<"Nodes in A cycle " <<" ";
                for (int m = l; m < a.elements.size() -1; m++)
                {
                    cycleElementsA.push_back(a.elements.at(m));
                    std::cout<< a.elements.at(m) <<", ";
                }
            }
        }
        std::cout<<std::endl;

        for (int n = 0; n < b.elements.size() -1 ; n++)
        {
            int countB = std::count(b.elements.begin(), b.elements.end(), b.elements.at(n));
            //std::cout<<"Num " << a.cycleElem.at(l) << "appears " << mycount <<std::endl;

            if (countB > 1)
            {
                std::cout<<"Nodes in B cycle "<<" ";
                for (int p = n; p < b.elements.size() -1; p++)
                {
                    cycleElementsB.push_back(b.elements.at(p));
                    std::cout<< b.elements.at(p) <<", ";
                }
            }
        }
        std::cout<<std::endl;

        if (cycleElementsA.size() == cycleElementsB.size())
        {
            int i;
            int j = -1;
            for ( i = 0; i < cycleElementsB.size(); i++)
            {
                if (cycleElementsA.at(0) == cycleElementsB.at(i))
                {
                    j = i;
                    std::cout << j << std::endl;
                }

            }

            if (j == -1)
            {
                std::cerr<< "Error: No same node" << std::endl;
                return false;
            }

            int counter = 0;
            for (int z = 0; z < cycleElementsB.size(); z++)
            {
                if(cycleElementsA.at(z) == cycleElementsB.at((z+j) % cycleElementsB.size()))
                {
                    counter+=1;
                    if (counter == cycleElementsB.size())
                    {
                        return true;
                    }
                }
                else
                {
                    std::cerr<<"No same elementary cycles "<<std::endl;
                    return false;
                }

            }
        }
        else
        {
            std::cout << "No elementary cycles "<<std::endl;
            return false;
        }

    }
    else
    {
        std::cout<<"No, there are no cycles in atleast A or B"<<std::endl;
    }
}

int main() {
    // Two directed graphs
    DirectedGraph a(7);
    a.edge(0, 1);
    a.edge(1, 2);
    //a.edge(1, 4);
    a.edge(2, 4);
    a.edge(3, 4);
    //a.edge(3, 5);
    a.edge(4, 5);
    a.edge(5, 6);
    a.edge(6, 3);

    //a.edge(4, 1);

    //a.edge(5, 1);

    DirectedGraph b(7);
    b.edge(0, 1);
    b.edge(1, 2);
    b.edge(2, 3);
    b.edge(3, 4);
    b.edge(4, 5);
    b.edge(5, 6);
    //b.edge(6, 4);
    //b.edge(4, 4);

    /*

    if (a.Cycle() && b.Cycle())
    {
        std::cout <<"There exist cycles in A and B"<<std::endl;
        bool flag = false;

        std::vector<int> cycleElementsA;
        std::vector<int> cycleElementsB;

        std::cout<<"Checking for elementary cycles"<<std::endl;

        //Cycle in a

        for (int l = 0; l < a.elements.size() -1 ; l++)
        {
            int countA = std::count(a.elements.begin(), a.elements.end(), a.elements.at(l));
            //std::cout<<"Num " << a.cycleElem.at(l) << "appears " << mycount <<std::endl;

            if (countA > 1)
            {
                std::cout<<"Nodes in A cycle " <<" ";
                for (int m = l; m < a.elements.size() -1; m++)
                {
                    cycleElementsA.push_back(a.elements.at(m));
                    std::cout<< a.elements.at(m) <<", ";
                }
            }
        }
        std::cout<<std::endl;

        for (int n = 0; n < b.elements.size() -1 ; n++)
        {
            int countB = std::count(b.elements.begin(), b.elements.end(), b.elements.at(n));
            //std::cout<<"Num " << a.cycleElem.at(l) << "appears " << mycount <<std::endl;

            if (countB > 1)
            {
                std::cout<<"Nodes in B cycle "<<" ";
                for (int p = n; p < b.elements.size() -1; p++)
                {
                    cycleElementsB.push_back(b.elements.at(p));
                    std::cout<< b.elements.at(p) <<", ";
                }
            }
        }
        std::cout<<std::endl;

        if (cycleElementsA.size() == cycleElementsB.size())
        {
            int i;
            int j = -1;
            for ( i = 0; i < cycleElementsB.size(); i++)
            {
                if (cycleElementsA.at(0) == cycleElementsB.at(i))
                {
                    j = i;
                    std::cout << j << std::endl;
                }

            }

            if (j == -1)
            {
                std::cerr<< "Error: No same node" << std::endl;
            }

            for (int z = 0; z < cycleElementsB.size(); z++)
            {
                if(cycleElementsA.at(z) == cycleElementsB.at((z+j) % cycleElementsB.size()))
                {
                    flag = true;
                    continue;
                }
                else
                {
                    flag = false;
                    std::cerr<<"No same elementary cycles "<<std::endl;
                }
            }
        }
        else
        {
            flag = false;
            std::cout << "No elementary cycles "<<std::endl;
        }

        if (flag == true)
        {
            std::cout<<"Directed Graphs have same elementary cycles" <<std::endl;
        }


    }
    else
    {
        std::cout<<"No, there are no cycles in atleast A or B"<<std::endl;
    }
    */

    ElemCycle C;
    if (C.haveSameElemCycles( a, b))
    {
        std::cout<<"Elementary cycles"<<std::endl;
    }
    else
    {
        std::cout<<"No elementary cycles"<<std::endl;
    }

    return 0;
}
