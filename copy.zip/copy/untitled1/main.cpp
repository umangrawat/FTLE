#include <iostream>

class X
{
public:
    int foo() const
    {
        return 3;
    }

    int foo()
    {
        return 2;
    }
};

int main() {
    //int a = 2;
    //int *b = &a;
    //std::cout << &a << std::endl;
    //return 0;
    X a;
    const X b;
    std::cout << a.foo()<< " "<< b.foo()<<std::endl;
}